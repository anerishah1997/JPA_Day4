package com.lti;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.lti.model.Student;

public class Main 
{
    public static void main( String[] args )
    {
    	SessionFactory factory =new Configuration().configure().buildSessionFactory();
    	Session session = factory.openSession();
    	session.beginTransaction();
    	Student student = new Student(1, "Makarand", 60);
    	session.save(student);
    	session.getTransaction().commit();
    	System.out.println("student data saved.");
    }
}
